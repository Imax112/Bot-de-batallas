import os
import discord
from discord.ext import commands
import random

intents = discord.Intents.default()
intents.message_content = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.command()
async def batalla(ctx, pais1: str, pais2: str):
    fuerza_pais1 = random.randint(500, 1000)
    fuerza_pais2 = random.randint(500, 1000)

    vida_pais1 = random.randint(1000, 2000)
    vida_pais2 = random.randint(1000, 2000)

    resultado1 = (vida_pais1 + fuerza_pais1) * random.uniform(0.8, 1.2)
    resultado2 = (vida_pais2 + fuerza_pais2) * random.uniform(0.8, 1.2)

    total = resultado1 + resultado2
    porcentaje1 = (resultado1 / total) * 100
    porcentaje2 = (resultado2 / total) * 100

    bajas1 = random.randint(100, 300)
    bajas2 = random.randint(100, 300)

    await ctx.send(f"**{pais1}**: {porcentaje1:.2f}% de victoria | Bajas: {bajas1}
"
                   f"**{pais2}**: {porcentaje2:.2f}% de victoria | Bajas: {bajas2}")

bot.run(os.getenv("TOKEN"))